import React from 'react'
import CarMo2App from './components/CarMo2App'

function App() {
  return <CarMo2App />
}

export default App